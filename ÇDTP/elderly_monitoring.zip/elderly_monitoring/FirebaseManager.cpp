#include "FirebaseManager.h"

FirebaseManager::FirebaseManager()
    : lastSendTime(0), wifiConnected(false) {}

bool FirebaseManager::begin(const Config& cfg) {
    config = cfg;
    return connectWiFi();
}

bool FirebaseManager::connectWiFi() {
    WiFi.mode(WIFI_STA);
    WiFi.begin(config.wifiSSID.c_str(),
               config.wifiPassword.c_str());

    int attempt = 0;
    while (WiFi.status() != WL_CONNECTED && attempt < 20) {
        delay(500);
        attempt++;
    }

    wifiConnected = (WiFi.status() == WL_CONNECTED);
    return wifiConnected;
}

bool FirebaseManager::isConnected() const {
    return wifiConnected && WiFi.status() == WL_CONNECTED;
}

String FirebaseManager::buildFirebaseURL(const String& path) const {
    String url = config.databaseURL;
    if (!url.endsWith("/")) url += "/";
    url += path;
    if (!url.endsWith(".json")) url += ".json";
    return url;
}

/* ================= MANUEL JSON ================= */
/* void FirebaseManager::buildHealthDataJSON(const HealthData& d,
                                          char* out, size_t size) {
    snprintf(
        out, size,
        "{"
        "\"heartRate\":%.1f,"
        "\"totalAcceleration\":%.2f,"
        "\"isMoving\":%s,"
        "\"batteryLevel\":%d,"
        "\"alertStatus\":%d,"
        "\"timestamp\":%lu"
        "}",
        d.heartRate,
        d.totalAcceleration,
        d.isMoving ? "true" : "false",
        d.batteryLevel,
        d.alertStatus,
        d.timestamp
    );
}*/   

void FirebaseManager::buildHealthDataJSON(const HealthData& d,
                                          char* out,
                                          size_t size) {
    float hr = d.heartRate;

    // 🔒 NaN / INF / negatif koruması
    if (isnan(hr) || isinf(hr) || hr < 0) {
        hr = 0.0f;
    }

    snprintf(
        out, size,
        "{"
          "\"heartRate\":%.1f,"
          "\"totalAcceleration\":%.2f,"
          "\"isMoving\":%s,"
          "\"batteryLevel\":%d,"
          "\"alertStatus\":%d,"
          "\"timestamp\":%lu"
        "}",
        hr,
        d.totalAcceleration,
        d.isMoving ? "true" : "false",
        d.batteryLevel,
        d.alertStatus,
        d.timestamp
    );
}


bool FirebaseManager::sendHTTPRequest(const char* jsonData) {
    if (!isConnected()) return false;

    HTTPClient http;
    String url = buildFirebaseURL("health_data");

    http.begin(url);
    http.addHeader("Content-Type", "application/json");

    int code = http.PUT(jsonData);
    http.end();

    return (code == 200 || code == HTTP_CODE_OK);
}

bool FirebaseManager::sendHealthData(const HealthData& data) {
    char json[256];
    buildHealthDataJSON(data, json, sizeof(json));

    Serial.print("[Firebase JSON] ");
    Serial.println(json);

    bool ok = sendHTTPRequest(json);
    if (ok) {
        lastData = data;
        lastSendTime = millis();
    } else {
        Serial.println("[Firebase] GONDERIM BASARISIZ");
    }

    return ok;
}

bool FirebaseManager::updateHealthData(float hr, float accel,
                                       bool moving,
                                       int battery,
                                       int alertStatus) {
    HealthData d;
    d.heartRate = hr;
    d.totalAcceleration = accel;
    d.isMoving = moving;
    d.batteryLevel = battery;
    d.alertStatus = alertStatus;
    d.timestamp = millis();

    return sendHealthData(d);
}

bool FirebaseManager::shouldSendData() {
    if (!config.enableAutoSend) return false;
    return (millis() - lastSendTime) >= config.sendInterval;
}

void FirebaseManager::printStatus() const {
    Serial.printf("[Firebase] WiFi: %s\n",
                  isConnected() ? "BAGLI" : "BAGLI DEGIL");
}
