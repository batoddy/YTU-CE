#ifndef FIREBASE_MANAGER_H
#define FIREBASE_MANAGER_H

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>

class FirebaseManager {
public:
    struct Config {
        String wifiSSID;
        String wifiPassword;
        String databaseURL;
        unsigned long sendInterval;
        bool enableAutoSend;

        Config() {
            wifiSSID = "";
            wifiPassword = "";
            databaseURL =
              "https://cdtp-saglik-takip-default-rtdb.europe-west1.firebasedatabase.app";
            sendInterval = 5000;
            enableAutoSend = true;
        }
    };

    struct HealthData {
        float heartRate;
        float totalAcceleration;
        bool isMoving;
        int batteryLevel;
        int alertStatus;
        unsigned long timestamp;
    };

    FirebaseManager();

    bool begin(const Config& cfg);
    bool connectWiFi();
    bool isConnected() const;

    bool sendHealthData(const HealthData& data);
    bool updateHealthData(float hr, float accel, bool moving,
                          int battery, int alertStatus = 0);

    bool shouldSendData();
    void printStatus() const;

private:
    Config config;
    HealthData lastData;
    unsigned long lastSendTime;
    bool wifiConnected;

    String buildFirebaseURL(const String& path) const;
    bool sendHTTPRequest(const char* jsonData);

    // 🔥 MANUEL JSON
    void buildHealthDataJSON(const HealthData& data,
                             char* out, size_t outSize);
};

#endif
