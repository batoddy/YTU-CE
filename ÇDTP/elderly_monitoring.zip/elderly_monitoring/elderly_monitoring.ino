#include "SensorManager.h"
#include "AlertSystem.h"
#include "FirebaseManager.h"


#define WIFI_NAME  "cdtp2526"
#define WIFI_PSWD  "cdtp2526"

#define DB_LINK "https://cdtp-saglik-takip-default-rtdb.europe-west1.firebasedatabase.app/"

#define FIREBASE_SEND_INTERVAL_SEC  2   // saniye

// ================== GLOBAL NESNELER ==================
SensorManager sensors;
AlertSystem alerts;
FirebaseManager firebase;

// ================== DONANIM ==================
const int EMERGENCY_BUTTON_PIN = 4;
volatile int batteryLevel = 85;

// ================== TASK HANDLE ==================
TaskHandle_t sensorTaskHandle = NULL;
TaskHandle_t wifiTaskHandle   = NULL;

// ================== SENSOR TASK (CORE 1) ==================
void sensorTask(void* pvParameters) {
    SensorManager::Config sensorConfig;
    sensorConfig.debug = true;

    if (!sensors.begin(sensorConfig)) {
        Serial.println("Sensor baslatilamadi!");
        vTaskDelete(NULL);
    }

    AlertSystem::Config alertConfig;
    alertConfig.enableSerial = true;
    alertConfig.alertCooldownMs = 3000;
    alerts.begin(alertConfig);

    pinMode(EMERGENCY_BUTTON_PIN, INPUT_PULLUP);
    bool lastButtonState = HIGH;
    unsigned long lastDebounceTime = 0;

    for (;;) {
        sensors.fastUpdate();
        sensors.slowUpdate();
        auto data = sensors.getData();

        if (sensors.isDusmeAlgilandi()) {
            alerts.sendAlert(AlertSystem::ALERT_DUSME,
                             "Dusme tespit edildi!",
                             data.toplamIvme);
        }

        if (sensors.isNabizAnormal()) {
            float hr = data.currentHR;
            if (hr < 40 || hr > 120) {
                alerts.sendAlert(AlertSystem::ALERT_NABIZ_YUKSEK,
                                 "Anormal nabiz!",
                                 hr);
            }
        }

        int reading = digitalRead(EMERGENCY_BUTTON_PIN);
        if (reading != lastButtonState) {
            lastDebounceTime = millis();
        }

        if ((millis() - lastDebounceTime) > 50 && reading == LOW) {
            alerts.handleEmergencyButton();
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
        lastButtonState = reading;

        bool normal =
    !sensors.isDusmeAlgilandi() &&
    !sensors.isNabizAnormal() &&
    !sensors.isHareketsizlikUzun();

if (normal) {
    alerts.sendAlert(
        AlertSystem::ALERT_SISTEM,
        "Durum normal"
    );
}


        vTaskDelay(pdMS_TO_TICKS(10)); // 🔴 kritik
    }
}

// ================== WIFI TASK (CORE 0) ==================
void wifiTask(void* pvParameters) {
    FirebaseManager::Config firebaseConfig;
    firebaseConfig.wifiSSID = WIFI_NAME;
    firebaseConfig.wifiPassword = WIFI_PSWD;
    firebaseConfig.databaseURL = DB_LINK;
    firebaseConfig.sendInterval = FIREBASE_SEND_INTERVAL_SEC * 1000UL;

    firebaseConfig.enableAutoSend = true;

    firebase.begin(firebaseConfig);

    int alertStatus = alerts.getCurrentAlertStatus();
    
    for (;;) {
        if (firebase.isConnected() && firebase.shouldSendData()) {
            auto data = sensors.getData();
            bool moving = data.toplamIvme > 0.3;

            firebase.updateHealthData(
                data.stableHR,
                data.toplamIvme,
                moving,
                batteryLevel,
                alertStatus
            );
        }

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

// ================== SETUP ==================
void setup() {
    Serial.begin(115200);
    delay(1000);

    xTaskCreatePinnedToCore(
        sensorTask,
        "SensorTask",
        8192,
        NULL,
        2,
        &sensorTaskHandle,
        1
    );

    xTaskCreatePinnedToCore(
        wifiTask,
        "WiFiTask",
        8192,
        NULL,
        1,
        &wifiTaskHandle,
        0
    );
}

// ================== LOOP ==================
void loop() {
    vTaskDelay(portMAX_DELAY);
}
