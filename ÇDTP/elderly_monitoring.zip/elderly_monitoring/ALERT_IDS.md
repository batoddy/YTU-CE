# Alert Sistemİ - ID Listesi ve Firebase Formatı

## 📊 Firebase Veri Formatı

```json
{
  "health_data": {
    "heartRate": 72,              // Nabız (bpm)
    "totalAcceleration": 0.98,    // Toplam ivme (g)
    "isMoving": true,             // Hareket durumu
    "batteryLevel": 85,           // Batarya seviyesi (%)
    "alertStatus": 0,             // Alert ID (aşağıda detaylı)
    "timestamp": 123456789        // Zaman damgası (milisaniye)
  }
}
```

## 🚨 Alert ID Listesi

| Alert ID | Alert Adı | Öncelik | Açıklama | Tetiklenme Koşulu |
|----------|-----------|---------|----------|-------------------|
| **0** | NORMAL | - | Herşey normal | Alert yok |
| **1** | DÜŞME | KRİTİK | Düşme tespit edildi | Ani ivme (>2.5g) + hareketsizlik |
| **2** | NABIZ DÜŞÜK | YÜKSEK | Düşük nabız (bradikardi) | Nabız < 40 bpm veya sensör kaybı |
| **3** | NABIZ YÜKSEK | YÜKSEK | Yüksek nabız (taşikardi) | Nabız > 120 bpm |
| **4** | HAREKETSIZLIK | ORTA | Uzun süre hareketsizlik | 5 dakika hareket yok |
| **5** | MANUEL ACIL | KRİTİK | Kullanıcı acil butona bastı | Acil buton aktivasyonu |

## 📱 Mobil Uygulama İçin Kullanım

### Alert Durumuna Göre Renk Kodları

```javascript
const alertColors = {
  0: '#4CAF50',  // Yeşil - Normal
  1: '#F44336',  // Kırmızı - Düşme
  2: '#FF9800',  // Turuncu - Nabız Düşük
  3: '#FF9800',  // Turuncu - Nabız Yüksek
  4: '#FFC107',  // Sarı - Hareketsizlik
  5: '#D32F2F'   // Koyu Kırmızı - Manuel Acil
};

const alertMessages = {
  0: 'Normal',
  1: '🚨 DÜŞME TESPİT EDİLDİ!',
  2: '⚠️ Nabız Düşük',
  3: '⚠️ Nabız Yüksek',
  4: '⚠️ Hareketsizlik',
  5: '🆘 MANUEL ACİL DURUM'
};
```

### Firebase Listener Örneği (JavaScript)

```javascript
import { getDatabase, ref, onValue } from "firebase/database";

const db = getDatabase();
const healthRef = ref(db, 'health_data');

onValue(healthRef, (snapshot) => {
  const data = snapshot.val();
  
  // Alert kontrolü
  if (data.alertStatus !== 0) {
    // Alert var!
    handleAlert(data.alertStatus, data);
  }
  
  // UI güncelle
  updateUI(data);
});

function handleAlert(alertId, data) {
  switch(alertId) {
    case 1: // DÜŞME
      sendPushNotification('DÜŞME TESPİT EDİLDİ!', 'Acil yardım gerekli!');
      callEmergencyContacts();
      break;
      
    case 2: // NABIZ DÜŞÜK
      sendPushNotification('Nabız Düşük', `Nabız: ${data.heartRate} bpm`);
      break;
      
    case 3: // NABIZ YÜKSEK
      sendPushNotification('Nabız Yüksek', `Nabız: ${data.heartRate} bpm`);
      break;
      
    case 4: // HAREKETSIZLIK
      sendPushNotification('Hareketsizlik', '5 dakikadır hareket algılanmadı');
      break;
      
    case 5: // MANUEL ACIL
      sendPushNotification('MANUEL ACİL DURUM!', 'Kullanıcı yardım çağırdı');
      callEmergencyContacts();
      break;
  }
}
```

### React Native Örneği

```javascript
import database from '@react-native-firebase/database';
import PushNotification from 'react-native-push-notification';

// Firebase listener
database()
  .ref('/health_data')
  .on('value', snapshot => {
    const data = snapshot.val();
    
    // Alert kontrolü
    if (data.alertStatus !== 0) {
      const alertInfo = getAlertInfo(data.alertStatus);
      
      // Push notification gönder
      PushNotification.localNotification({
        channelId: alertInfo.priority === 'CRITICAL' ? 'critical-channel' : 'normal-channel',
        title: alertInfo.title,
        message: alertInfo.message,
        playSound: true,
        soundName: alertInfo.sound,
        priority: alertInfo.priority === 'CRITICAL' ? 'max' : 'high',
        vibrate: true,
        vibration: alertInfo.priority === 'CRITICAL' ? 1000 : 300,
      });
    }
    
    // UI güncelle
    updateHealthUI(data);
  });

function getAlertInfo(alertId) {
  const alerts = {
    1: {
      title: '🚨 DÜŞME!',
      message: 'Acil yardım gerekli!',
      priority: 'CRITICAL',
      sound: 'emergency.mp3'
    },
    2: {
      title: '⚠️ Nabız Düşük',
      message: 'Nabız normalin altında',
      priority: 'HIGH',
      sound: 'alert.mp3'
    },
    3: {
      title: '⚠️ Nabız Yüksek',
      message: 'Nabız normalin üstünde',
      priority: 'HIGH',
      sound: 'alert.mp3'
    },
    4: {
      title: '⚠️ Hareketsizlik',
      message: '5 dakikadır hareket yok',
      priority: 'MEDIUM',
      sound: 'warning.mp3'
    },
    5: {
      title: '🆘 ACİL DURUM!',
      message: 'Kullanıcı yardım çağırdı',
      priority: 'CRITICAL',
      sound: 'emergency.mp3'
    }
  };
  
  return alerts[alertId] || {
    title: 'Bildirim',
    message: 'Bilinmeyen alert',
    priority: 'LOW',
    sound: 'default'
  };
}
```

## 🔔 Alert Yönetimi

### Otomatik Alert Sıfırlama

Alert durumu manuel veya otomatik olarak sıfırlanmalıdır:

```cpp
// ESP32 tarafında
// Normal durum algılandığında alertStatus = 0 gönder
firebase.updateHealthData(
    data.stableHR,
    data.toplamIvme,
    isMoving,
    batteryLevel,
    0  // Normal duruma döndü
);
```

### Alert Geçmişi Kaydetme (Önerilen)

Firebase'de alert geçmişini kaydetmek için:

```javascript
// Mobil uygulama tarafında
if (data.alertStatus !== 0) {
  // Alert geçmişine kaydet
  database().ref(`alert_history/${Date.now()}`).set({
    alertId: data.alertStatus,
    heartRate: data.heartRate,
    acceleration: data.totalAcceleration,
    batteryLevel: data.batteryLevel,
    timestamp: data.timestamp,
    resolvedAt: null  // Alert çözüldüğünde güncellenir
  });
}
```

Firebase yapısı:

```
firebase-root/
├── health_data/          # Güncel sağlık verileri
│   ├── heartRate: 72
│   ├── alertStatus: 1
│   └── ...
└── alert_history/        # Alert geçmişi
    ├── 1704441600000/
    │   ├── alertId: 1
    │   ├── heartRate: 72
    │   └── resolvedAt: 1704441700000
    └── 1704445200000/
        └── ...
```

## 📊 Alert İstatistikleri

### Günlük/Haftalık Rapor

```javascript
// Alert sayılarını hesapla
database()
  .ref('alert_history')
  .orderByChild('timestamp')
  .startAt(startDate)
  .endAt(endDate)
  .once('value', snapshot => {
    const alerts = snapshot.val();
    
    // Alert türlerine göre grupla
    const stats = {
      1: 0, // Düşme
      2: 0, // Nabız Düşük
      3: 0, // Nabız Yüksek
      4: 0, // Hareketsizlik
      5: 0  // Manuel
    };
    
    Object.values(alerts).forEach(alert => {
      stats[alert.alertId]++;
    });
    
    console.log('Alert İstatistikleri:', stats);
  });
```

## 🎯 Önemli Notlar

1. **Alert Cooldown**: ESP32 tarafında alert cooldown mekanizması var (3 saniye). Aynı alert tekrar tekrar gönderilmez.

2. **Kritik Alertler**: Düşme (1) ve Manuel Acil (5) alertleri için cooldown uygulanmaz, her defasında gönderilir.

3. **Normal Durum**: Her 5 saniyede bir normal veri gönderilir (alertStatus=0). Alert bittiğinde bu otomatik sıfırlanır.

4. **Timestamp**: Tüm veriler ESP32'nin millis() değeri ile zaman damgalıdır. Mobil uygulamada mutlak zamana çevrilmelidir.

5. **Batarya**: Şu an simüle ediliyor. Gerçek projede ESP32'nin ADC'si ile ölçülmelidir.

## 🔐 Güvenlik Önerileri

1. **Firebase Rules**: Üretimde authentication ekleyin
2. **Alert Verification**: Sahte alertlere karşı doğrulama ekleyin
3. **Rate Limiting**: Çok fazla alert gönderimini engelleyin
4. **Encryption**: Hassas verileri şifreleyin

## 📱 Önerilen Mobil UI

### Alert Card Tasarımı

```
┌─────────────────────────────────┐
│ 🚨 DÜŞME TESPİT EDİLDİ!        │
│                                  │
│ Zaman: 14:32                    │
│ Nabız: 72 bpm                   │
│ İvme: 3.45 g                    │
│ Batarya: 85%                    │
│                                  │
│ [ACİL ARAMA] [KONUMU GÖR]      │
└─────────────────────────────────┘
```

### Normal Durum Dashboard

```
┌─────────────────────────────────┐
│ ✅ Herşey Normal                │
│                                  │
│ 💓 Nabız: 72 bpm                │
│ 🏃 Hareket: Aktif               │
│ 🔋 Batarya: 85%                 │
│ 📍 Son güncelleme: 2 sn önce    │
└─────────────────────────────────┘
```

---

**Not**: Bu döküman, yaşlı takip sistemi projesi için alert yönetimi ve Firebase entegrasyonu rehberidir.
