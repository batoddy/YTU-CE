package Hospital;

interface IMedicalPersonnel {
 String getName();
}

