package Hospital;

class SurgeryUnsuccessfulException extends Exception {
 public SurgeryUnsuccessfulException(String message) {
     super(message);
 }
}