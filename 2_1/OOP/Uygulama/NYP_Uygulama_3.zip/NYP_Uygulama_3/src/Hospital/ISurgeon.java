package Hospital;

interface ISurgeon {
 void performSurgery() throws SurgeryUnsuccessfulException;
}

