package batuhanodcikin;

import java.util.List;

public class Market {

	public static void simulatePurchases(List<Customer> customers, List<Product> products) {
		
	}
	
	public static void printCustomerSpending(List<Customer> customers) {
		
	}
	public static void printTotalIncome(List<Customer> customers) {
	}
}

