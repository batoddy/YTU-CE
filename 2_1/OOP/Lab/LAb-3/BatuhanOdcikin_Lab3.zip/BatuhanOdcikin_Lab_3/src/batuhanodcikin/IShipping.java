package batuhanodcikin;

public interface IShipping {
	boolean shipProduct(String productName, String customerName);
}
