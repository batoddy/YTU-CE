package batuhanodcikin;

public class ProductShippingError extends Exception{
	 public ProductShippingError(String message) {
		System.out.println(message);
	}
}
