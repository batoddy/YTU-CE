package batuhanodcikin;

public interface IProduct {

	String getName();
	double getPrice();
}
