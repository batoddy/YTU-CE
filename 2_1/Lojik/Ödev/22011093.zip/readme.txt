Simülasyon digital üzerinden yapılmıştır.

Batuhan Odçıkın - 22011093