from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='reservation',
            name='delivered_at',
            field=models.DateTimeField(blank=True, null=True, verbose_name='Teslim Tarihi'),
        ),
    ]
