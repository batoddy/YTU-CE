from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ('core', '0002_reservation_delivered_at'),
    ]

    operations = [
        migrations.CreateModel(
            name='ToolRating',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('score', models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)], verbose_name='Puan')),
                ('comment', models.TextField(blank=True, null=True, verbose_name='Yorum')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('reservation', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='tool_rating', to='core.reservation', verbose_name='Rezervasyon')),
                ('tool', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='tool_ratings', to='core.tool', verbose_name='Alet')),
            ],
            options={
                'db_table': 'tool_ratings',
                'verbose_name': 'Alet Degerlendirme',
                'verbose_name_plural': 'Alet Degerlendirmeler',
            },
        ),
        migrations.AddConstraint(
            model_name='toolrating',
            constraint=models.CheckConstraint(condition=models.Q(('score__gte', 1), ('score__lte', 5)), name='tool_rating_score_range'),
        ),
    ]
